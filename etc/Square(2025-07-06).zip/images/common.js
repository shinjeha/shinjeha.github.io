$(document).ready(function() {
	//txc-info wrap
	$('.txc-info').wrap('<div class="txc-info-wrap"></div>');

	//smart device responsive video
	if ($('body').width() < "960") {
		$('iframe[src*=youtube],iframe[src*=video],video').wrap('<div class="responsive-video"></div>');
	}

	$("#sidebar-toggle").click(function(){
		$("html").toggleClass("open");
	});
});